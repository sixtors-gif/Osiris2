
function findAPI(win){
  var tries=0;
  while(win && tries<10){
    try{ if(win.API) return win.API; }catch(e){}
    try{ if(win.parent && win.parent!==win){win=win.parent;}else break;}catch(e){break;}
    tries++;
  }
  return null;
}
var api=findAPI(window);
function scormInit(){
  try{
    if(api && api.LMSInitialize){
      api.LMSInitialize("");
      api.LMSSetValue("cmi.core.lesson_status","incomplete");
      api.LMSCommit("");
    }
  }catch(e){}
}
function scormComplete(score){
  try{
    if(api && api.LMSSetValue){
      api.LMSSetValue("cmi.core.lesson_status","completed");
      if(score!==undefined) api.LMSSetValue("cmi.core.score.raw",String(score));
      api.LMSCommit("");
    }
  }catch(e){}
}
function markComplete(){scormComplete();}
window.addEventListener("load",scormInit);
window.addEventListener("beforeunload",function(){try{if(api&&api.LMSFinish)api.LMSFinish("");}catch(e){}});
