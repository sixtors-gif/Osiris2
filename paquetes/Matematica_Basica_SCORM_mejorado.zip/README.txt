MATEMÁTICA BÁSICA — SCORM 1.2

Curso independiente con:
- 10 módulos didácticos.
- Actividades interactivas de respuesta inmediata.
- Repaso de 5 preguntas.
- Examen final de 20 preguntas.
- Banco de 40 preguntas en formato GIFT para Moodle.

INSTALACIÓN EN MOODLE
1. Añade una actividad SCORM.
2. Sube Matematica_Basica_SCORM.zip.
3. Guarda los cambios.
4. Para el banco de preguntas, importa preguntas_moodle.gift desde Banco de preguntas > Importar > GIFT.

El paquete no modifica ni depende del curso de Ciberseguridad.
